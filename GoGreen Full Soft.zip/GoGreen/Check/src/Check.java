import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Check {
    public static void main(String[] args) {
        String apiEndPoint="https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
        String location="London,UK";
        StringBuilder requestBuilder=new StringBuilder(apiEndPoint);

        try {
            requestBuilder.append(URLEncoder.encode(location, StandardCharsets.UTF_8.toString()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println(requestBuilder);
    }
}
