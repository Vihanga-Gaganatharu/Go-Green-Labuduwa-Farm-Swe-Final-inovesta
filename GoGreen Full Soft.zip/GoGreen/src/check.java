import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class check {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.of(2023, 9, 17);
        java.time.DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        System.out.println("Day of week in text:"+dayOfWeek.toString());

    }
}
