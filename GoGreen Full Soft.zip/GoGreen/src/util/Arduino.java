package util;
import com.fazecast.jSerialComm.SerialPort;
public class Arduino {
        public static void loadArduino() {

            SerialPort[] ports = SerialPort.getCommPorts();
            if (ports.length == 0) {
                System.out.println("No serial ports found.");
                return;
            }
            SerialPort port = SerialPort.getCommPort("COM5"); // Choose the appropriate port

            if (port.openPort()) {
                System.out.println("Port opened successfully.");
                port.setBaudRate(9600); // Set the same baud rate as in your Arduino code

                StringBuilder receivedData = new StringBuilder();

                while (true) {
                    byte[] readBuffer = new byte[128];
                    int numRead = port.readBytes(readBuffer, readBuffer.length);

                    if (numRead > 0) {
                        String data = new String(readBuffer, 0, numRead);

                        // Append received data to the StringBuilder
                        receivedData.append(data);

                        // Check if we have received a complete line of data
                        if (receivedData.toString().contains("\n")) {
                            String[] values = receivedData.toString().trim().split(",");

                            if (values.length == 3) {
                                try {
                                    double temperature = Double.parseDouble(values[0]);
                                    double humidity = Double.parseDouble(values[1]);
                                    int moisture = Integer.parseInt(values[2]);

                                    // Now you have the temperature, humidity, and moisture values in your Java program
                                    //System.out.println("Temperature: " + temperature + "°C");
                                  //  System.out.println("Humidity: " + humidity + "%");
                                    //System.out.println("Moisture: " + moisture + "%");
                                } catch (NumberFormatException e) {
                                    System.err.println("Error parsing values: " + e.getMessage());
                                }
                            }

                            // Clear the receivedData StringBuilder for the next set of data
                            receivedData.setLength(0);
                        }
                    }
                }
            } else {
                System.err.println("Failed to open the port.");
            }
        }

}
