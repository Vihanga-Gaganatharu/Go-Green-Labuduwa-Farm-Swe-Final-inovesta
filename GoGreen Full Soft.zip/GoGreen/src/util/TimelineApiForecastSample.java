package util;/*
 * TimelineApiSample
 * Example to show how to call the Visual Crossing Timeline Weather API using Java.
 * See https://www.visualcrossing.com/resources/documentation/weather-api/how-to-use-timeline-weather-api-to-retrieve-historical-weather-data-and-weather-forecast-data-in-java/
 */


import dto.custom.Weather;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;


public class TimelineApiForecastSample {

	public static ArrayList<Weather> getWeatherList() throws Exception {

		String apiEndPoint="https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
		String location="SriLanka,Galle";
		String startDate=null;
		String endDate=null;

		String unitGroup="metric";
		String apiKey="QUHCZBH9D54AFT54V99CTY44B";

		StringBuilder requestBuilder=new StringBuilder(apiEndPoint);
		requestBuilder.append(URLEncoder.encode(location, StandardCharsets.UTF_8.toString()));

		if (startDate!=null && !startDate.isEmpty()) {
			requestBuilder.append("/").append(startDate);
			if (endDate!=null && !endDate.isEmpty()) {
				requestBuilder.append("/").append(endDate);
			}
		}

		URIBuilder builder = new URIBuilder(requestBuilder.toString());

		builder.setParameter("unitGroup", unitGroup)
				.setParameter("key", apiKey);



		HttpGet get = new HttpGet(builder.build());

		CloseableHttpClient httpclient = HttpClients.createDefault();

		CloseableHttpResponse response = httpclient.execute(get);

		String rawResult=null;
		try {
			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				System.out.printf("Bad response status code:%d%n", response.getStatusLine().getStatusCode());
			}else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					rawResult=EntityUtils.toString(entity, Charset.forName("utf-8"));
				}
			}
		} finally {
			response.close();
		}
		ArrayList<Weather> weathers=new ArrayList<>();
		if (rawResult==null || rawResult.isEmpty()) {
			System.out.printf("No raw data%n");

		}else {
			JSONObject timelineResponse = new JSONObject(rawResult);

			ZoneId zoneId=ZoneId.of(timelineResponse.getString("timezone"));

			System.out.printf("Weather data for: %s%n", timelineResponse.getString("resolvedAddress"));

			JSONArray values=timelineResponse.getJSONArray("days");

			System.out.printf("Date\tMaxTemp\tMinTemp\tPrecip\tSource%n");
			for (int i = 0; i < 7; i++) {
				JSONObject dayValue = values.getJSONObject(i);

				ZonedDateTime datetime=ZonedDateTime.ofInstant(Instant.ofEpochSecond(dayValue.getLong("datetimeEpoch")), zoneId);

				double maxtemp=dayValue.getDouble("tempmax");
				double mintemp=dayValue.getDouble("tempmin");
				double pop=dayValue.getDouble("precip");
				String source=dayValue.getString("source");

				 weathers.add(new Weather(maxtemp,mintemp,pop,source,String.valueOf(datetime)));
				// System.out.printf("%s\t%.1f\t%.1f\t%.1f\t%s%n", datetime.format(DateTimeFormatter.ISO_LOCAL_DATE), maxtemp, mintemp, pop,source );

			}
		}
		return weathers;
	}
}
