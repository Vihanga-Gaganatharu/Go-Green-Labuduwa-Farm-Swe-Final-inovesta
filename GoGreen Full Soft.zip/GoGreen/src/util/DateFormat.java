package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateFormat {
    public static String dateFormatter(String string) {
        System.out.println(string);
        return string;
        /*DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
        if (string != null && !string.isEmpty()) {
            return String.valueOf(LocalDate.parse(string, dateFormatter));
        } else {
            return null;
        }*/
    }
}
