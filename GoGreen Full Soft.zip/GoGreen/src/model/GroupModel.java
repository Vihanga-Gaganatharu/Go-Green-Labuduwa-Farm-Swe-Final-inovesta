package model;

import db.DBConnection;
import dto.GreenHouse;
import dto.GreenHouseSection;
import dto.Group;
import javafx.scene.control.Alert;
import util.CrudUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class GroupModel {
    public static boolean add(Group group, HashMap<String, Integer> sectionData, String greenHouseId) throws SQLException, ClassNotFoundException {
        Connection connection = null;
        try {
            connection = DBConnection.getInstance().getConnection();
            connection.setAutoCommit(false);
            if (addGroup(group)) {
                if (GroupDetailsModel.add(group.getGroup_id(),greenHouseId)) {
                    if (update(sectionData,greenHouseId)) {
                        connection.commit();
                        return true;
                    } else {
                        connection.rollback();
                        new Alert(Alert.AlertType.ERROR," fail !").show();
                    }
                } else {
                    connection.rollback();
                    new Alert(Alert.AlertType.ERROR," fail !").show();
                }
            } else {
                connection.rollback();
                new Alert(Alert.AlertType.ERROR," fail !").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }finally {
            connection.setAutoCommit(true);
        }
        return false;


    }

    private static boolean update(HashMap<String, Integer> sectionData, String greenHouseId) throws SQLException, ClassNotFoundException {
        boolean returnResult=false;
        ArrayList<GreenHouseSection> list = GreenHouseSectionModel.get(greenHouseId);
        for (int i = 0; i < list.size(); i++) {
            returnResult=CrudUtil.crudUtil("UPDATE green_house_section set plant=? WHERE section_id=?",sectionData.get(list.get(i)),list.get(i));
        }
        return returnResult;
    }

    private static boolean addGroup(Group group) throws SQLException, ClassNotFoundException {
         return CrudUtil.crudUtil("INSERT INTO `group` VALUES (?,?,?,?,?,?,?)",
                group.getGroup_id(),
                group.getQty(),
                group.getDate(),
                group.getDescription(),
                group.getStatus(),
                group.getDamage(),
                group.getPlant_id()
                );
    }

    public static ArrayList<GreenHouse> getAll() throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT * FROM green_house");
        ArrayList<GreenHouse> list = new ArrayList<>();
        while (set.next()) {
            list.add(new GreenHouse(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4)
            ));
        }
        return list;
    }

    public static Group get(String txtId) throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT group_id FROM `group` WHERE group_id=?",txtId);

        while (set.next()) {
          return   new Group(
                    set.getString(1),
                    set.getInt(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    set.getInt(6),
                    set.getString(7)
            );
        }
        return null;
    }

    public static boolean update(Group g) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE `group` SET status=?,date=?,plant_id=?,qty=?,Damage=?,description=? WHERE group_id=?",
                g.getStatus(),
                g.getDate(),
                g.getPlant_id(),
                g.getQty(),
                g.getDamage(),
                g.getDescription(),
                g.getGroup_id()

                );
    }
}
