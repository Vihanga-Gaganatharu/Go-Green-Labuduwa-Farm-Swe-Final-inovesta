package model;

import db.DBConnection;
import db.Db;
import dto.Water;
import javafx.scene.control.Alert;
import util.CrudUtil;

import java.sql.Connection;
import java.sql.SQLException;

public class WaterModel {

    public static boolean add(Water manual) throws SQLException {
        System.out.println(manual.toString());
        Connection connection = null;
        try {
            connection = DBConnection.getInstance().getConnection();
            connection.setAutoCommit(false);
            if (addWater(manual)) {
                if (addSection(manual)) {
                    connection.commit();
                    return true;
                  //  new Alert(Alert.AlertType.ERROR,"addSection fail !").show();

                } else {
                    connection.rollback();
                    new Alert(Alert.AlertType.ERROR,"addWater fail !").show();
                }
            } else {
                connection.rollback();
                new Alert(Alert.AlertType.ERROR,"Order fail !").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }finally {
            connection.setAutoCommit(true);
        }
        return false;
    }

    private static boolean addSection(Water manual) throws SQLException, ClassNotFoundException {
        boolean b=false;

        for (int i = 0; i < Db.waterApplyManually.size(); i++) {
            System.out.println(Db.waterApplyManually.get(i));
            b =CrudUtil.crudUtil("INSERT INTO water_apply_section VALUES (?,?)",
                    manual.getWater_id(),
                    Db.waterApplyManually.get(i)
            );
        }
        return b;
    }

    private static boolean addWater(Water manual) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO water VALUES (?,?,?,?,?,?)",
                manual.getWater_id(),
                manual.getTime(),
                manual.getDate(),
                manual.getStates(),
                manual.getTemp(),
                manual.getSoil_moisture()
                );
    }
}
