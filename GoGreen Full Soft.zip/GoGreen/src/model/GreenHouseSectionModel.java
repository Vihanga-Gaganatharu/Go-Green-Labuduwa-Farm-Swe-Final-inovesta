package model;

import dto.GreenHouseSection;
import dto.custom.WaterGreenHouseDetails;
import util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GreenHouseSectionModel {
    public static ArrayList<GreenHouseSection> get(String id) throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT * FROM green_house_section WHERE section_id=?", id);
        ArrayList<GreenHouseSection> list = new ArrayList<>();
        while (set.next()) {
            list.add(new GreenHouseSection(
                    set.getString(1),
                    set.getString(2),
                    Integer.parseInt(set.getString(3)),
                    Integer.parseInt(set.getString(4))
            ));
        }
        return list;
    }

    public static ArrayList<WaterGreenHouseDetails> getAll() throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT DISTINCT\n" +
                "        g.green_house_id,\n" +
                "       p.plant,\n" +
                "       w.time,\n" +
                "       w.date,\n" +
                "       w.temp,\n" +
                "       w.soil_moisture,\n" +
                "       w.states\n" +
                "FROM water w\n" +
                "    inner join water_apply_section was on w.water_id = was.water_id\n" +
                "    inner join green_house_section gs on was.green_house_section_id = gs.green_house_section_id\n" +
                "    inner join green_house g on gs.section_id = g.green_house_id\n" +
                "    inner join green_house_details ghd on g.green_house_id = ghd.green_house_id\n" +
                "    inner join `group` g2 on ghd.group_id = g2.group_id\n" +
                "    inner join plant p on g2.plant_id = p.plant_id");
        ArrayList<WaterGreenHouseDetails> list = new ArrayList<>();
        while (set.next()) {
            list.add(new WaterGreenHouseDetails(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    set.getString(6),
                    set.getString(7)
            ));
        }
        return list;
    }
}
