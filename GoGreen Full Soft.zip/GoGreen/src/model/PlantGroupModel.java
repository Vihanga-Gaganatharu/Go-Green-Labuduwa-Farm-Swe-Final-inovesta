package model;

import dto.custom.PlantGroupCust;
import util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlantGroupModel {
    public static ArrayList<PlantGroupCust> get() throws SQLException, ClassNotFoundException {
        ArrayList<PlantGroupCust> list=new ArrayList<>();
        ResultSet set= CrudUtil.crudUtil("SELECT g.group_id,p.plant,g.qty,g.Damage,g.date,g.status FROM `group` g inner JOIN plant p on g.plant_id = p.plant_id ");
        while (set.next()){
            list.add(new PlantGroupCust(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getDouble(3)-set.getDouble(4)+"",
                    set.getString(4),
                    set.getString(5),
                    set.getString(6)
            ));
        }
        return list;
    }

    public static ArrayList<String> getIds() throws SQLException, ClassNotFoundException {
        ArrayList<String> list=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT group_id FROM `group`");
        while (set.next()){
            list.add(set.getString(1));
        }
        return list;
    }

    public static boolean remove(String text) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("DELETE FROM `group` WHERE group_id=?",text);
    }

    public static ArrayList<PlantGroupCust> getSearchData(String txt) throws SQLException, ClassNotFoundException {
        ArrayList<PlantGroupCust> list=new ArrayList<>();
        ResultSet set= CrudUtil.crudUtil("SELECT g.group_id,p.plant,g.qty,g.Damage,g.date,g.status FROM `group` g inner JOIN plant p on g.plant_id = p.plant_id WHERE group_id LIKE ? or p.plant like ?","%"+txt,"%"+txt);
        while (set.next()){
            list.add(new PlantGroupCust(
                set.getString(1),
                set.getString(2),
                set.getString(3),
                    set.getDouble(3)-set.getDouble(4)+"",
                set.getString(4),
                set.getString(5),
                set.getString(6)
            ));
        }
        return list;
    }
}
