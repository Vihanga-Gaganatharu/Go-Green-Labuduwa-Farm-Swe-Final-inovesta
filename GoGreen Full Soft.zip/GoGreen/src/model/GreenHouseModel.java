package model;

import db.DBConnection;
import db.Db;
import dto.GreenHouse;
import dto.GreenHouseSection;
import dto.custom.GreenHouseViewData;
import javafx.scene.control.Alert;
import util.CrudUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GreenHouseModel {
    public static boolean add(GreenHouse greenHouse) throws SQLException, ClassNotFoundException {

        Connection connection = null;
        try {
            connection = DBConnection.getInstance().getConnection();
            connection.setAutoCommit(false);
            if (setGreenHouse(greenHouse)) {
                if (setSection(greenHouse)) {
                    connection.commit();
                    return true;
                } else {
                    connection.rollback();
                    new Alert(Alert.AlertType.ERROR,"Order fail !").show();
                }
            } else {
                connection.rollback();
                new Alert(Alert.AlertType.ERROR,"Order fail !").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }finally {
            connection.setAutoCommit(true);
        }
        return false;


    }

    private static boolean setSection(GreenHouse greenHouse) throws SQLException, ClassNotFoundException {
            boolean b=false;
        for (int i = 0; i < Db.sectionDB.size(); i++) {
            b= CrudUtil.crudUtil("INSERT INTO green_house_section VALUES (?,?,?,?)",
                    "@S0"+i,
                    greenHouse.getGreen_house_id(),
                    0,
                    Db.sectionDB.get("@S0"+i)
            );
        }
        Db.sectionDB.clear();
        return b;


    }

    private static boolean setGreenHouse(GreenHouse greenHouse) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO green_house VALUES (?,?,?,?)",
                greenHouse.getGreen_house_id(),
                greenHouse.getDate(),
                greenHouse.getLocation(),
                greenHouse.getApply_to_water()
        );
    }

    public static ArrayList<GreenHouseViewData> getAll() {
        return null;
    }

    public static ArrayList<GreenHouseViewData> getAllViewData() throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT gh.green_house_id,gh.location,gh.date,p.plant,g.qty,gh.apply_to_water FROM green_house gh INNER JOIN green_house_details ghd on gh.green_house_id = ghd.green_house_id\n" +
                "                                           INNER JOIN `group` g on ghd.group_id = g.group_id\n" +
                "                                           INNER JOIN plant p on g.plant_id = p.plant_id");
        ArrayList<GreenHouseViewData> list = new ArrayList<>();
        while (set.next()) {
            list.add(new GreenHouseViewData(
                set.getString(1),
                set.getString(2),
                set.getString(3),
                set.getString(4),
                set.getString(5),
                "4",
                set.getString(6)
            ));
        }
        return list;
    }

    public static boolean remove(String id) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("DELETE FROM green_house WHERE green_house_id=?",id);
    }

    public static ArrayList<GreenHouseViewData> getAllSearchData(String text) throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT gh.green_house_id,gh.location,gh.date,p.plant,g.qty,g.status FROM green_house gh INNER JOIN green_house_details ghd on gh.green_house_id = ghd.green_house_id\n" +
                "                                                                                        INNER JOIN `group` g on ghd.group_id = g.group_id\n" +
                "                                                                                        INNER JOIN plant p on g.plant_id = p.plant_id WHERE gh.green_house_id LIKE ?",text+"%");
        ArrayList<GreenHouseViewData> list = new ArrayList<>();
        while (set.next()) {
            list.add(new GreenHouseViewData(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    "4",
                    set.getString(6)
            ));
        }
        return list;
    }

    public static boolean udate(GreenHouse g) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE green_house set date=?,location=?,apply_to_water=? where green_house_id=?",
                g.getDate(),
                g.getLocation(),
                g.getApply_to_water(),
                g.getGreen_house_id()
        );
    }

    public static boolean statusUpdate(String auto,String id) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE green_house SET apply_to_water=? WHERE green_house_id=?",auto,id);
    }

    public static ArrayList<GreenHouseSection> getSection() throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT * FROM green_house_section");
        ArrayList<GreenHouseSection> list = new ArrayList<>();
        while (set.next()) {
            list.add(new GreenHouseSection(
                    set.getString(1),
                    set.getString(2),
                    Integer.parseInt(set.getString(3)),
                    Integer.parseInt(set.getString(4))
            ));
        }
        return list;
    }
}
