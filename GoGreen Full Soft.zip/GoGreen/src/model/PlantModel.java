package model;

import dto.Plant;
import dto.custom.PlantGroupCust;
import util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlantModel {
    public static boolean add(Plant plant) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO plant VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                plant.getPlant_id(),
                plant.getPlant(),
                plant.getMin_soil_moisture(),
                plant.getMax_soil_moisture(),
                plant.getAvg_soil_moisture(),
                plant.getMin_temp(),
                plant.getMax_temp(),
                plant.getAvg_temp(),
                plant.getHarvest_time(),
                plant.getLife_time(),
                plant.getWater_per_day(),
                plant.getWater_liter_per_day(),
                plant.getTime_paired_for_water(),
                plant.getDescription()
        );
    }

    public static Plant get(String textId) throws SQLException, ClassNotFoundException {
        ResultSet set = CrudUtil.crudUtil("SELECT * FROM plant WHERE plant_id=?", textId);
        while (set.next()) {
            return new Plant(
                    set.getString(1),
                    set.getString(2),
                    Double.parseDouble(set.getString(3)),
                    Double.parseDouble(set.getString(4)),
                    Double.parseDouble(set.getString(5)),
                    Double.parseDouble(set.getString(6)),
                    Double.parseDouble(set.getString(7)),
                    Double.parseDouble(set.getString(8)),
                    Integer.parseInt(set.getString(9)),
                    Integer.parseInt(set.getString(10)),
                    Integer.parseInt(set.getString(11)),
                    Double.parseDouble(set.getString(12)),
                    Double.parseDouble(set.getString(13)),
                    set.getString(14)
            );
        }
        return null;
    }

    public static boolean update(Plant p) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE plant\n" +
                "SET plant=?,\n" +
                "    min_soil_moisture=?,\n" +
                "    max_soil_moisture=?,\n" +
                "    avg_soil_moisture=?,\n" +
                "    min_temp=?,\n" +
                "    max_temp=?,\n" +
                "    avg_temp=?,\n" +
                "    harvest_time=?,\n" +
                "    life_time=?,\n" +
                "    water_per_day=?,\n" +
                "    water_liter_per_day=?,\n" +
                "    time_paired_for_water=?,\n" +
                "    description=?\n" +
                "WHERE plant_id = ?",
                p.getPlant(),
                p.getMin_soil_moisture(),
                p.getMax_soil_moisture(),
                p.getAvg_soil_moisture(),
                p.getMin_temp(),
                p.getMax_temp(),
                p.getAvg_temp(),
                p.getHarvest_time(),
                p.getLife_time(),
                p.getWater_per_day(),
                p.getWater_liter_per_day(),
                p.getTime_paired_for_water(),
                p.getDescription(),
                p.getPlant_id()



        );
    }

    public static boolean remove(String text) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("DELETE FROM plant WHERE plant_id=?",text);
    }

    public static ArrayList<Plant> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Plant> list=new ArrayList<>();
        ResultSet set= CrudUtil.crudUtil("SELECT * FROM plant");
        while (set.next()){
            list.add(new Plant(
                    set.getString(1),
                    set.getString(2),
                    Double.parseDouble(set.getString(3)),
                    Double.parseDouble(set.getString(4)),
                    Double.parseDouble(set.getString(5)),
                    Double.parseDouble(set.getString(6)),
                    Double.parseDouble(set.getString(7)),
                    Double.parseDouble(set.getString(8)),
                    Integer.parseInt(set.getString(9)),
                    Integer.parseInt(set.getString(10)),
                    Integer.parseInt(set.getString(11)),
                    Double.parseDouble(set.getString(12)),
                    Double.parseDouble(set.getString(13)),
                    set.getString(14)
            ));
        }
        return list;

//        SELECT * FROM plant
    }

    public static ArrayList<Plant> getAllSearch(String txt) throws SQLException, ClassNotFoundException {
        ArrayList<Plant> list=new ArrayList<>();
        ResultSet set= CrudUtil.crudUtil("SELECT * FROM plant WHERE plant_id like ? or plant like ? ",txt+"%",txt+"%");
        while (set.next()){
            list.add(new Plant(
                    set.getString(1),
                    set.getString(2),
                    Double.parseDouble(set.getString(3)),
                    Double.parseDouble(set.getString(4)),
                    Double.parseDouble(set.getString(5)),
                    Double.parseDouble(set.getString(6)),
                    Double.parseDouble(set.getString(7)),
                    Double.parseDouble(set.getString(8)),
                    Integer.parseInt(set.getString(9)),
                    Integer.parseInt(set.getString(10)),
                    Integer.parseInt(set.getString(11)),
                    Double.parseDouble(set.getString(12)),
                    Double.parseDouble(set.getString(13)),
                    set.getString(14)
            ));
        }
        return list;
    }
}
