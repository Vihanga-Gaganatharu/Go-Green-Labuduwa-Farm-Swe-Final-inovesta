package model;

import util.CrudUtil;

import java.sql.SQLException;

public class GroupDetailsModel {
    public static boolean add(String group_id, String greenHouseId) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO green_house_details VALUES (?,?)",greenHouseId,group_id);
    }
}
