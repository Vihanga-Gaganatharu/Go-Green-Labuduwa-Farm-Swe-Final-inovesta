package model;

import dto.Employee;
import util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeModel {
    public static boolean add(Employee employee) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO employee VALUES (?,?,?,?,?,?,?,?,?)",
                employee.getNic(),
                employee.getFist_name(),
                employee.getLast_name(),
                employee.getCity(),
                employee.getLane(),
                employee.getStreet(),
                employee.getHome_no(),
                employee.getEmail(),
                employee.getMobile_no()
                );
    }

    public static Employee get(String id) throws SQLException, ClassNotFoundException {
        ResultSet set=CrudUtil.crudUtil("SELECT * FROM employee WHERE nic=?",id);
        if (set.next()){
            return new Employee(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5),
                    set.getString(6),
                    set.getString(7),
                    set.getString(8),
                    set.getString(9)
            );
        }
        return null;
    }

    public static boolean update(Employee employee) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("UPDATE employee SET fist_name=?,last_name=?,city=?,lane=?,street=?,home_no=?,email=?,mobile_no=? WHERE nic=?",
                employee.getFist_name(),
                employee.getLast_name(),
                employee.getCity(),
                employee.getLane(),
                employee.getStreet(),
                employee.getHome_no(),
                employee.getEmail(),
                employee.getMobile_no(),
                employee.getNic()
        );
    }

    public static ArrayList<String> getAllIds() throws SQLException, ClassNotFoundException {
        ArrayList<String>list=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT nic FROM employee");
        while (set.next()){
            list.add(set.getString(1));
        }
        return list;
    }

    public static boolean remove(String nic) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("DELETE FROM employee WHERE nic=?",nic);
    }

    public static ArrayList<String> getAllIdsFilter(String nic) throws SQLException, ClassNotFoundException {
        ArrayList<String>list=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT nic FROM employee WHERE nic LIKE ?",nic+"%");
        while (set.next()){
            list.add(set.getString(1));
        }
        return list;
    }
}
