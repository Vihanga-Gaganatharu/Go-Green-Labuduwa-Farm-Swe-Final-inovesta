package model;

import dto.Attendance;
import util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeAttendanceModel {
    public static boolean add(Attendance attendance) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("INSERT INTO attendance VALUES (?,?,?,?)",
                attendance.getDate(),
                attendance.getIn_time(),
                attendance.getOut_time(),
                attendance.getEmployee_id()
                );
    }

    public static ArrayList<Attendance> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Attendance>list=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT a.date,a.in_time,a.out_time,a.employee_id,e.fist_name,e.last_name,e.home_no,e.city,e.lane,e.street FROM attendance a INNER JOIN employee e on a.employee_id = e.nic");

        while (set.next()){
            list.add(new Attendance(
                 set.getString(1),
                 set.getString(2),
                 set.getString(3),
                 set.getString(4),
                 set.getString(5)+" "+
                 set.getString(6),
                 set.getString(7)+" "+
                 set.getString(8)+","+
                 set.getString(9)+","+
                 set.getString(10)
            ));
        }
        return list;
    }

    public static ArrayList<Attendance> getAllFilter(String text) throws SQLException, ClassNotFoundException {
        ArrayList<Attendance>list=new ArrayList<>();
        ResultSet set=CrudUtil.crudUtil("SELECT a.date,a.in_time,a.out_time,a.employee_id,e.fist_name,e.last_name,e.home_no,e.city,e.lane,e.street FROM attendance a INNER JOIN employee e on a.employee_id = e.nic WHERE employee_id LIKE ? or date LIKE ?",text+"%",text+"%");

        while (set.next()){
            list.add(new Attendance(
                    set.getString(1),
                    set.getString(2),
                    set.getString(3),
                    set.getString(4),
                    set.getString(5)+" "+
                            set.getString(6),
                    set.getString(7)+" "+
                            set.getString(8)+","+
                            set.getString(9)+","+
                            set.getString(10)
            ));
        }
        return list;
    }
}
