package dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class GreenHouseSection {
    String green_house_section_id;
    String section_id;
    int plant;
    int plantLimit;

}
