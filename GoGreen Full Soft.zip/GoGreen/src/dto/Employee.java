package dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Employee {
    String nic;
    String fist_name;
    String last_name;
    String city;
    String lane;
    String street;
    String home_no;
    String email;
    String mobile_no;

}
