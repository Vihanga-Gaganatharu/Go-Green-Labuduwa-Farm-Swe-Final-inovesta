package dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Plant {
    private String plant_id;
    private String plant;
    private double min_soil_moisture;
    private double max_soil_moisture;
    private double avg_soil_moisture;
    private double min_temp;
    private double max_temp;
    private double avg_temp;
    private int harvest_time;
    private int life_time;
    private int water_per_day;
    private double water_liter_per_day;
    private double time_paired_for_water;
    private String description;

}
