package dto.custom;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PlantGroupCust {
    String id;
    String plant;
    String count;
    String LCount;
    String DCount;
    String Date;
    String Status;
}
