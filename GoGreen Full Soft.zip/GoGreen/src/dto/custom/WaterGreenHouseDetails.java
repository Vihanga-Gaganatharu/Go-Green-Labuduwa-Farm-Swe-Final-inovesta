package dto.custom;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class WaterGreenHouseDetails {
    String green_house_id;
    String plant;
    String time;
    String date;
    String temp;
    String soil_moisture;
    String states;

}
