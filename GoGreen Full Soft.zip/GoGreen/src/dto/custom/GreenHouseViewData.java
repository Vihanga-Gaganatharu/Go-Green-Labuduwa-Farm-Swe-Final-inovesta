package dto.custom;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class GreenHouseViewData {
    String green_house_id;
    String location;
    String date;
    String plant;
    String plantCount;
    String section;
    String apply_to_water;

}
