package dto.custom;


public class AD {
    private String temperature;
    private String humidity;

    public AD() {
    }

    private String moisture;

    public AD(String temperature, String humidity, String moisture) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.moisture = moisture;
        System.out.println(temperature);
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getMoisture() {
        return moisture;
    }

    public void setMoisture(String moisture) {
        this.moisture = moisture;
    }
}
