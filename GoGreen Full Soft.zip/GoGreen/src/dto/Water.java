package dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Water {
    String water_id;
    String time;
    String date;
    String states;
    double temp;
    double soil_moisture;
}
