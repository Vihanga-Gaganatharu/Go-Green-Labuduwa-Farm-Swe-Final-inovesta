package dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Group {
    String group_id;
    int qty;
    String date;
    String description;
    String status;
    int Damage;
    String plant_id;


}
