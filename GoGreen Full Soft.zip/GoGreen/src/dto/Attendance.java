package dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Attendance {
    String date;
    String in_time;
    String out_time;
    String employee_id;
    String name;
    String address;

}
