package db;

import dto.custom.AD;

import java.util.ArrayList;
import java.util.HashMap;

public class Db {
    public static HashMap<String, AD>db=new HashMap<>();
    public static HashMap<String, String>sectionDB=new HashMap<>();
    public static ArrayList<String> waterApplyManually =new ArrayList<>();

}
