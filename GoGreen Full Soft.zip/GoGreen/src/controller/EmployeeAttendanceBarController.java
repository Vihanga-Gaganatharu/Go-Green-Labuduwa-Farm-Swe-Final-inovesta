package controller;

import dto.Attendance;
import javafx.scene.text.Text;

import java.util.ArrayList;

public class EmployeeAttendanceBarController {
    public Text txtAttendance;
    public Text txtName;
    public Text txtAddress;
    public Text txtDate;
    public Text txtTime;
    public Text txtOutTime;

    public void setData(Attendance a) {
        txtAttendance.setText(a.getEmployee_id());
        txtName.setText(a.getName());
        txtAddress.setText(a.getAddress());
        txtDate.setText(a.getDate());
        txtTime.setText(a.getIn_time());
        txtOutTime.setText(a.getOut_time());
    }
}
