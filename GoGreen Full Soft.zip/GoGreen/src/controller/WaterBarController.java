package controller;

import dto.custom.GreenHouseViewData;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Text;
import model.EmployeeModel;
import model.GreenHouseModel;
import util.Navigation;

import java.sql.SQLException;

public class WaterBarController {
    public Text txtId;
    public Text txtLocation;
    public Text txtApple;
    public Text txtPlant;
    public Text txtSection;
    public Text txtStatus;

    public void applyWaterOnAction(ActionEvent actionEvent) {
    if (txtStatus.getText().equals("MANUAL")){
        Navigation.popupNavigation("SectionSelectViewfrom.fxml");
    }else {

    }

    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION, "Are Your Sure ? ", ButtonType.OK,ButtonType.NO);
            alert.showAndWait();
            if (alert.getButtonTypes().equals(ButtonType.OK)){
                if (GreenHouseModel.remove(txtId.getText())){
                    new Alert(Alert.AlertType.CONFIRMATION,"ok").show();
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void updateOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("GreenHouseUpdateFrom.fxml");
    }

    public void setData(GreenHouseViewData data) {
        txtId.setText(data.getGreen_house_id());
        txtLocation.setText(data.getLocation());
        txtApple.setText(data.getPlant());
        txtPlant.setText(data.getPlantCount());
        txtSection.setText(data.getSection());
        txtStatus.setText(data.getApply_to_water());
    }

    public void switchOnAction(ActionEvent actionEvent) {
        try {
            if (txtStatus.getText().equals("MANUAL")){
                GreenHouseModel.statusUpdate("AUTO",txtId.getText());
            }else if (txtStatus.getText().equals("AUTO")){
                GreenHouseModel.statusUpdate("MANUAL",txtId.getText());
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

        WaterManageController.getController().setGreenHouseData();
    }
}
