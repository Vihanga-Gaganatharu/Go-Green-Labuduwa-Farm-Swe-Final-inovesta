package controller;

import com.jfoenix.controls.JFXTextField;
import dto.Plant;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.text.Text;
import model.PlantModel;

import java.sql.SQLException;

public class PlantAddFromController {
    public JFXTextField txtSoilMoistureMin;
    public JFXTextField txtSoilMoistureMax;
    public JFXTextField txtSoilMoistureAVG;
    public JFXTextField txtTempMax;
    public Text txtTempMin;
    public JFXTextField txtTempAVG;
    public JFXTextField txtPlant;
    public JFXTextField txtDescription;
    public JFXTextField txtHarvestTime;
    public JFXTextField txtLifeTime;
    public JFXTextField txtWaterPerDay;
    public JFXTextField txtWaterTimePaired;
    public JFXTextField txtWaterLitterInOne;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (PlantModel.add(new Plant(
                    getNewId(),
                    txtPlant.getText(),
                    Double.parseDouble(txtSoilMoistureMin.getText()),
                    Double.parseDouble(txtSoilMoistureMax.getText()),
                    Double.parseDouble(txtSoilMoistureAVG.getText()),
                    Double.parseDouble(txtTempMin.getText()),
                    Double.parseDouble(txtTempMax.getText()),
                    Double.parseDouble(txtTempAVG.getText()),
                    Integer.parseInt(txtHarvestTime.getText()),
                    Integer.parseInt(txtLifeTime.getText()),
                    Integer.parseInt(txtWaterPerDay.getText()),
                    Double.parseDouble(txtWaterLitterInOne.getText()),
                    Double.parseDouble(txtWaterTimePaired.getText()),
                    txtDescription.getText()

            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }


    }

    private String getNewId() {
        return "@P001";
    }

    public void closeOnAction(ActionEvent actionEvent) {

    }
}
