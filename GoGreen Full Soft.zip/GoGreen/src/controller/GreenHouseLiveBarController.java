package controller;

import db.Db;
import dto.custom.GreenHouseViewData;
import javafx.scene.text.Text;

import java.util.Random;

import static java.lang.Thread.sleep;

public class GreenHouseLiveBarController {
    public Text txtTemp;
    public Text txtGreenHouseId;
    public Text txtSm;
    public Text txtH;

    public void setData(GreenHouseViewData data) {
        txtGreenHouseId.setText(data.getGreen_house_id());
        try {
            txtTemp.setText(Db.db.get("G001").getTemperature());
            txtSm.setText(Db.db.get("G001").getMoisture());
            txtH.setText(Db.db.get("G001").getHumidity());
        }catch (NullPointerException e){
            Thread thread=new Thread(() -> {
                Random r1=new Random();
                Random r2=new Random();
                Random r3=new Random();

                while (true){

                    txtTemp.setText(String.valueOf(r1.nextInt(25)));
                    txtSm.setText(String.valueOf(r3.nextInt(50))+"%");
                    txtH.setText(String.valueOf(r2.nextInt(50))+"%");
                    try {
                        sleep(8000);
                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                }


            });
            thread.start();
        }

    }
}
