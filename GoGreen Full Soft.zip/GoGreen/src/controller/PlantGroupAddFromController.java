package controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dto.GreenHouse;
import dto.GreenHouseSection;
import dto.Group;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.GreenHouseModel;
import model.GreenHouseSectionModel;
import model.GroupModel;
import util.DateFormat;
import util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

public class PlantGroupAddFromController implements Initializable {
    public static HashMap<String, Integer> sectionData = new HashMap<String, Integer>();
    public JFXTextField txtCount;
    public JFXTextField txtDCount;
    public JFXComboBox cmbStatus;
    public JFXDatePicker dpDate;
    public JFXComboBox cmbPlantId;
    public Text txtPlant;
    public JFXTextField txtDescription;
    public VBox vBox;
    public JFXComboBox cmbGroupId;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (GroupModel.add(new Group(
                    getNewId(),
                    Integer.parseInt(txtCount.getText()),
                    DateFormat.dateFormatter(String.valueOf(dpDate.getValue())),
                    txtDescription.getText(),
                    String.valueOf(cmbStatus.getValue()),
                    Integer.parseInt(txtDCount.getText()),
                    String.valueOf(cmbPlantId.getValue())
            ),sectionData,String.valueOf(cmbGroupId.getValue()))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private String getNewId() {
        return "@G001";
    }

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ArrayList<String> WPT = new ArrayList<>();
        WPT.add("On Live");
        WPT.add("Dead");
        cmbStatus.getItems().addAll(WPT);
        setPlantIds();
        loadGroupId();

    }

    private void loadGroupId() {
        try {
            ArrayList<GreenHouse> list = GroupModel.getAll();
            ArrayList<String>ids=new ArrayList<>();
            for (GreenHouse g : list) {
                ids.add(g.getGreen_house_id());
            }
            cmbGroupId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

    }

    private void loadSectionBar(GreenHouseSection data) {
        try {
            FXMLLoader loader = new FXMLLoader(PlantGroupAddFromController.class.getResource("/view/bar/GroupSectionBar.fxml"));
            Parent root = loader.load();
            GroupSectionBarController controller = loader.getController();
            controller.setData(data);
            vBox.getChildren().add(root);
        } catch (IOException e) {
        }
    }

    private void setPlantIds() {

    }

    public void greenHouseOnAction(ActionEvent actionEvent) {
        try {
            ArrayList<GreenHouseSection> list = GreenHouseSectionModel.get(String.valueOf(cmbGroupId.getValue()));
            for (GreenHouseSection data : list) {
                loadSectionBar(data);
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
