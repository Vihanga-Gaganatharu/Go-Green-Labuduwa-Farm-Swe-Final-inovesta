package controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dto.Group;
import dto.Plant;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.text.Text;
import model.GroupModel;
import model.PlantGroupModel;
import model.PlantModel;
import util.DateFormat;
import util.Navigation;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PlantGroupUpdateFromController implements Initializable {
    public JFXComboBox cmbStatus;
    public JFXDatePicker dpDate;
    public JFXComboBox cmbPlantId;
    public Text txtPlant;
    public JFXTextField txtDescription;
    public Text txtIds;

    public static String txtId;
    public JFXTextField txtCount;
    public JFXTextField txtDCount;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (GroupModel.update(new Group(
                    txtIds.getId(),
                    Integer.parseInt(txtCount.getText()),
                    dpDate.getValue()+"",
                    txtDescription.getText(),
                    String.valueOf(cmbStatus.getValue()),
                    Integer.parseInt(txtDCount.getText()),
                    String.valueOf(cmbPlantId.getValue())
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    public void cmbPlantIdOnAction(ActionEvent actionEvent) {
        try {
            Plant plant = PlantModel.get(cmbPlantId.getId());
            txtPlant.setText(plant.getPlant());
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setDataCmb();
        setData();
    }

    private void setData() {

        try {
            Group g= GroupModel.get(txtId);
              cmbStatus.setValue(g.getStatus());
              cmbPlantId.setValue(g.getPlant_id());
              txtCount.setText(String.valueOf(g.getQty()));
              txtDCount.setText(String.valueOf(g.getDamage()));
              txtDescription.setText(g.getDescription());
              txtIds.setText(g.getGroup_id());
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private void setDataCmb() {
        ArrayList<String>ids= null;
        try {
            ids = PlantGroupModel.getIds();
            cmbPlantId.getItems().addAll(ids);
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

    }
}
