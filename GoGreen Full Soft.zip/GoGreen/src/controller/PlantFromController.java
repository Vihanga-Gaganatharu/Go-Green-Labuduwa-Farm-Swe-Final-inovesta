package controller;

import dto.Plant;
import dto.custom.PlantGroupCust;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;
import model.PlantGroupModel;
import model.PlantModel;
import util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PlantFromController implements Initializable {

    private static PlantFromController controller;

    public PlantFromController() {
        controller=this;
    }

    public static PlantFromController getController() {
        return controller;
    }

    public VBox vBox;

    public void addOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("PlantAddFrom.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        setData();
    }

    public void setData() {
        vBox.getChildren().clear();
        try {
            ArrayList<Plant> plants= PlantModel.getAll();
            for (int i = 0; i < plants.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(PlantBarController.class.getResource("/view/bar/PlantBar.fxml"));
                    Parent root = loader.load();
                    PlantBarController controller = loader.getController();
                    controller.setData(plants.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }


    }
    public void setSearchData(String txt) {
        vBox.getChildren().clear();
        try {
            ArrayList<Plant> plants = PlantModel.getAllSearch(txt);
            for (int i = 0; i < plants.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(PlantBarController.class.getResource("/view/bar/PlantBar.fxml"));
                    Parent root = loader.load();
                    PlantBarController controller = loader.getController();
                    controller.setData(plants.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
