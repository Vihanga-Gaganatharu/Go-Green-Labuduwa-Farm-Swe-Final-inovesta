package controller;

import com.jfoenix.controls.JFXTextField;
import dto.Employee;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.text.Text;
import model.EmployeeModel;
import util.Navigation;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class EmployeeUpdateFromController implements Initializable {
    public JFXTextField txtFirstName;
    public JFXTextField txtLastName;
    public JFXTextField txtMail;
    public JFXTextField txtStreet;
    public JFXTextField txtLane;
    public JFXTextField txtCity;
    public JFXTextField txtContact;
//    public JFXTextField txtNic;
    public JFXTextField txtNo;

    public static String id;
    public Text txtNic2;


    public void updateOnAction(ActionEvent actionEvent) {
        try {
            if (EmployeeModel.update(new Employee(
                    txtNic2.getText(),
                    txtFirstName.getText(),
                    txtLastName.getText(),
                    txtCity.getText(),
                    txtLane.getText(),
                    txtStreet.getText(),
                    txtNo.getText(),
                    txtMail.getText(),
                    txtContact.getText()
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            Employee employee= EmployeeModel.get(id);
            txtNic2.setText(id);
            txtFirstName.setText(employee.getFist_name());
            txtLastName.setText(employee.getLast_name());
            txtCity.setText(employee.getCity());
            txtLane.setText(employee.getLane());
            txtStreet.setText(employee.getStreet());
            txtNo.setText(employee.getHome_no());
            txtMail.setText(employee.getEmail());
            txtContact.setText(employee.getMobile_no());
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }


    }
}
