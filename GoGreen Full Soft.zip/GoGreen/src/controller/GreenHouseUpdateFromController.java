package controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dto.GreenHouse;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.text.Text;
import model.GreenHouseModel;
import util.DateFormat;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class GreenHouseUpdateFromController implements Initializable {
    public JFXTextField txtLocation;
    public JFXComboBox cmbWAType;
    public JFXDatePicker dpDate;
    public Text txtID;

    public void closeOnAction(ActionEvent actionEvent) {

    }

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (GreenHouseModel.udate(new GreenHouse(
                    txtID.getText(),
                    DateFormat.dateFormatter(String.valueOf(dpDate.getValue())),
                    txtLocation.getText(),
                    String.valueOf(cmbWAType.getValue())
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ArrayList<String> WPT=new ArrayList<>();
        WPT.add("MANUAL");
        WPT.add("AUTO");
        cmbWAType.getItems().addAll(WPT);
    }
}
