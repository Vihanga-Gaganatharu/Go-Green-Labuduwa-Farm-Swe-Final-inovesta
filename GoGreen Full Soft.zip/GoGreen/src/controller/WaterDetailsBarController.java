package controller;

import dto.custom.WaterGreenHouseDetails;
import javafx.event.ActionEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import util.Navigation;

public class WaterDetailsBarController {
    public Text txtTime;
    public Text txtSection;
    public Text txtStatus;
    public Text txtPlant;
    public Text txtId;
    public Text txtDate;
    public Text txtTemp;
    public Text txtSM;

    public void findOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("SectionSelectedViewfrom.fxml");
    }

    public void setData(WaterGreenHouseDetails data) {
        txtId.setText(data.getGreen_house_id());
        txtPlant.setText(data.getPlant());
        txtTime.setText(data.getTime());
        txtDate.setText(data.getDate());
        txtTemp.setText(data.getTemp());
        txtSM.setText(data.getSoil_moisture());
        txtStatus.setText(data.getStates());
    }
}
