package controller;

import db.Db;
import dto.GreenHouseSection;
import dto.Water;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import model.GreenHouseModel;
import model.WaterModel;
import util.DateTimeUtil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SectionSelectViewFromController implements Initializable {
    static String id;
    public VBox vBox;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (WaterModel.add(new Water(
                    nextId(),
                    DateTimeUtil.timeNow(),
                    DateTimeUtil.dateNow(),
                    "manual" ,
                    Db.db.size() == 0 ? 22 : Double.parseDouble(Db.db.get(id).getTemperature()),
                    Db.db.size() == 0 ? 33 : Double.parseDouble(Db.db.get(id).getMoisture())
            ))) {
                WaterManageController.getController().setWaterData();
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    private String nextId() {
        return "@W03";
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        load();
    }

    private void load() {
        try {
            ArrayList<GreenHouseSection> section = GreenHouseModel.getSection();
            for (int i = 0; i < section.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(WaterApplySectionBarController.class.getResource("/view/bar/WaterApplySectionBar.fxml"));
                    Parent root = loader.load();
                    WaterApplySectionBarController controller = loader.getController();
                    controller.setData(section.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
