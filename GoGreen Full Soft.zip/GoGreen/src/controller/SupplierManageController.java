package controller;

import javafx.event.ActionEvent;

public class SupplierManageController {
    public void addFOnAction(ActionEvent actionEvent) {

    }
}
