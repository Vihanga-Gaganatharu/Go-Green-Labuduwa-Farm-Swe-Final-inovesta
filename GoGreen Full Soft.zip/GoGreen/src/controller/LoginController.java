package controller;

import javafx.event.ActionEvent;
import util.Navigation;

public class LoginController {
    public void loginOnAction(ActionEvent actionEvent) {
        Navigation.switchNavigation("Dashboard.fxml",actionEvent);
    }
}
