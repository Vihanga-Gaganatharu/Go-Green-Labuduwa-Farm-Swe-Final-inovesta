package controller;

import com.jfoenix.controls.JFXTextField;
import dto.Employee;
import dto.Plant;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.text.Text;
import model.EmployeeModel;
import model.PlantModel;
import util.Navigation;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class PlantUpdateFromController implements Initializable {
    public JFXTextField txtSoilMoistureMin;
    public JFXTextField txtSoilMoistureMax;
    public JFXTextField txtSoilMoistureAVG;
    public JFXTextField txtTempMax;
    public Text txtTempMin;
    public JFXTextField txtTempAVG;
    public JFXTextField txtPlant;
    public JFXTextField txtDescription;
    public JFXTextField txtWaterPerDay;
    public JFXTextField txtWaterTimePaired;
    public JFXTextField txtWaterLitterInOne;
    public JFXTextField txtHarvestTime;
    public JFXTextField txtLifeTime;
    public Text txtId;

    public static  String textId;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (PlantModel.update(new Plant(
                    txtId.getText(),
                    txtPlant.getText(),
                    Double.parseDouble(txtSoilMoistureMin.getText()),
                    Double.parseDouble(txtSoilMoistureMax.getText()),
                    Double.parseDouble(txtSoilMoistureAVG.getText()),
                    Double.parseDouble(txtTempMin.getText()),
                    Double.parseDouble(txtTempMax.getText()),
                    Double.parseDouble(txtTempAVG.getText()),
                    Integer.parseInt(txtHarvestTime.getText()),
                    Integer.parseInt(txtLifeTime.getText()),
                    Integer.parseInt(txtWaterPerDay.getText()),
                    Double.parseDouble(txtWaterLitterInOne.getText()),
                    Double.parseDouble(txtWaterTimePaired.getText()),
                    txtDescription.getText()
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setData();
    }

    private void setData() {
        try {
            Plant p=PlantModel.get(textId);

            System.out.println(p.toString());
            txtSoilMoistureMin.setText(String.valueOf(p.getMin_soil_moisture()));
            txtSoilMoistureMax.setText(String.valueOf(p.getMax_soil_moisture()));
            txtSoilMoistureAVG.setText(String.valueOf(p.getAvg_soil_moisture()));
            txtTempMax.setText(String.valueOf(p.getMax_temp()));
            txtTempMin.setText(String.valueOf(p.getMin_temp()));
            txtTempAVG.setText(String.valueOf(p.getAvg_temp()));
            txtPlant.setText(p.getPlant());
            txtDescription.setText(p.getDescription());
            txtWaterPerDay.setText(String.valueOf(p.getWater_per_day()));
            txtWaterTimePaired.setText(String.valueOf(p.getTime_paired_for_water()));
            txtWaterLitterInOne.setText(String.valueOf(p.getWater_liter_per_day()));
            txtHarvestTime.setText(String.valueOf(p.getHarvest_time()));
            txtLifeTime.setText(String.valueOf(p.getLife_time()));
            txtId.setText(p.getPlant_id());
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
