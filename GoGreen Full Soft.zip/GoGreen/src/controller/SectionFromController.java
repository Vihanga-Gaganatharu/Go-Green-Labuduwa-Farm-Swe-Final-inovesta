package controller;

import com.jfoenix.controls.JFXTextField;
import db.Db;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;

public class SectionFromController {
    public JFXTextField txtPlantCount;
    public Text txtId;

    public void onKeyReleaded(KeyEvent keyEvent) {
        Db.sectionDB.put(txtId.getText(),txtPlantCount.getText());
    }

    public void setData(int i) {
        txtId.setText("@S0"+i);
    }
}
