package controller;

import dto.Employee;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;
import model.EmployeeModel;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EmployeeController implements Initializable {
    private static EmployeeController controller;
    public EmployeeController() {
        controller=this;
    }
    public static EmployeeController getController() {
        return controller;
    }

    public VBox vBox;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        getIds();
    }

    public void getIds() {
        vBox.getChildren().clear();
        try {
            ArrayList<String>list= EmployeeModel.getAllIds();
            for (int i = 0; i < list.size(); i++) {
                setData(list.get(i));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

    }

    public  void setSearchData(String id) {
        vBox.getChildren().clear();
        try {
            ArrayList<String>list= EmployeeModel.getAllIdsFilter(id);
            for (int i = 0; i < list.size(); i++) {
                setData(list.get(i));
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
    public  void setData(String id) {
        try {
            Employee employee= EmployeeModel.get(id);
            try {
                FXMLLoader loader = new FXMLLoader(EmployeeBarController.class.getResource("/view/bar/EmployeeBar.fxml"));
                Parent root = loader.load();
                EmployeeBarController controller = loader.getController();
                controller.setData(employee);
                vBox.getChildren().add(root);
            } catch (IOException e) {
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
