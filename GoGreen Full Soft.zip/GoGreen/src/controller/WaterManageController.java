package controller;

import com.jfoenix.controls.JFXTextField;
import dto.custom.GreenHouseViewData;
import dto.custom.WaterGreenHouseDetails;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import model.GreenHouseModel;
import model.GreenHouseSectionModel;
import util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class WaterManageController implements Initializable {
        private static WaterManageController controller;
    public VBox vBox3;

    public WaterManageController() {
        controller=this;
    }

    public static WaterManageController getController() {
        return controller;
    }

    public VBox vBox2;
    public JFXTextField txtGreenHouseText;
    public VBox vBox;

    public void applyWaterOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("SectionSelectViewfrom.fxml");
    }

    public void findOnAction(ActionEvent actionEvent) {

    }

    public void addGreenHOuseOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("GreenHouseAddFrom.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setWaterData();
        setGreenHouseData();
        setLiveData();
    }

    private void setLiveData() {
        vBox3.getChildren().clear();
        try {
            ArrayList<GreenHouseViewData> list = GreenHouseModel.getAllViewData();
            for (GreenHouseViewData data : list) {
                try {
                    FXMLLoader loader = new FXMLLoader(GreenHouseLiveBarController.class.getResource("/view/bar/GreenHouseLiveBar.fxml"));
                    Parent root = loader.load();
                    GreenHouseLiveBarController controller = loader.getController();
                    controller.setData(data);
                    vBox3.getChildren().add(root);
                } catch (IOException e) {
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void setGreenHouseData() {
        vBox.getChildren().clear();
        try {
            ArrayList<GreenHouseViewData> list = GreenHouseModel.getAllViewData();
            for (GreenHouseViewData data : list) {
                loadGreenHouseData(data);
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private void loadGreenHouseData(GreenHouseViewData data) {
        try {
            FXMLLoader loader = new FXMLLoader(WaterBarController.class.getResource("/view/bar/WaterBar.fxml"));
            Parent root = loader.load();
            WaterBarController controller = loader.getController();
            controller.setData(data);
            vBox.getChildren().add(root);
        } catch (IOException e) {
        }
    }

    public void setWaterData() {
        vBox2.getChildren().clear();
        try {
            ArrayList<WaterGreenHouseDetails> list = GreenHouseSectionModel.getAll();
            for (WaterGreenHouseDetails data : list) {
                loadData(data);
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }


    }

    private void loadData(WaterGreenHouseDetails data) {
        try {
            FXMLLoader loader = new FXMLLoader(WaterDetailsBarController.class.getResource("/view/bar/WaterDetailsBar.fxml"));
            Parent root = loader.load();
            WaterDetailsBarController controller = loader.getController();
            controller.setData(data);
            vBox2.getChildren().add(root);
        } catch (IOException e) {
        }
    }

    public void keyReleased(KeyEvent keyEvent) {
            vBox.getChildren().clear();
        try {
            ArrayList<GreenHouseViewData> list = GreenHouseModel.getAllSearchData(txtGreenHouseText.getText());
            for (GreenHouseViewData data : list) {
                loadGreenHouseData(data);
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
