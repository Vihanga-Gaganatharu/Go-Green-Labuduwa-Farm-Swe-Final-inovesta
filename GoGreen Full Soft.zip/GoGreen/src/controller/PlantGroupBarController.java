package controller;

import dto.custom.PlantGroupCust;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Text;
import model.EmployeeModel;
import model.PlantGroupModel;
import util.Navigation;

import java.sql.SQLException;
import java.util.ArrayList;

public class PlantGroupBarController {

    public Text txtId;
    public Text txtPlant;
    public Text count;
    public Text txtPlantCount;
    public Text txtDate;
    public Text txtStatus;
    public Text txtDCount;

    public void update(ActionEvent actionEvent) {
        Navigation.popupNavigation("PlantGroupUpdateFrom.fxml");
    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are Your Sure ? ", ButtonType.OK, ButtonType.NO);
            alert.showAndWait();
            if (alert.getButtonTypes().equals(ButtonType.OK)) {
                if (PlantGroupModel.remove(txtId.getText())) {
                    new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void view(ActionEvent actionEvent) {
    }

    public void setData(PlantGroupCust p) {
        txtId.setText(p.getId());
        txtPlant.setText(p.getPlant());
        count.setText(p.getCount());
        txtPlantCount.setText(p.getPlant());
        txtDate.setText(p.getDate());
        txtStatus.setText(p.getStatus());
        txtDCount.setText(p.getDCount());
    }
}
