package controller;

import dto.Employee;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Text;
import model.EmployeeModel;
import util.Navigation;

import java.sql.SQLException;

public class EmployeeBarController {
    public Text txtId;
    public Text txtName;
    public Text txtAddress;
    public Text txtMail;
    public Text txtContact;

    public void updateOnAction(ActionEvent actionEvent) {
        EmployeeUpdateFromController.id=txtId.getText();
        Navigation.popupNavigation("EmployeeUpdateFrom.fxml");
    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION, "Are Your Sure ? ",ButtonType.OK,ButtonType.NO);
            alert.showAndWait();
            if (alert.getButtonTypes().equals(ButtonType.OK)){
                if (EmployeeModel.remove(txtId.getText())){
                    new Alert(Alert.AlertType.CONFIRMATION,"ok").show();
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }

    }

    public void setData(Employee employee) {
        txtId.setText(employee.getNic());
        txtAddress.setText(employee.getHome_no()+" "+employee.getCity()+","+employee.getLane()+","+employee.getStreet());
        txtName.setText(employee.getFist_name()+" "+employee.getLast_name());
        txtMail.setText(employee.getEmail());
        txtContact.setText(employee.getMobile_no());
    }
}
