package controller;

import dto.Plant;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Text;
import model.EmployeeModel;
import model.PlantModel;
import util.Navigation;

import java.sql.SQLException;

public class PlantBarController {

    public Text txtId;
    public Text txtPlant;
    public Text txtSm;
    public Text txtTem;
    public Text txtWPD;
    public Text txtHTime;
    public Text txtLifeTime;

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are Your Sure ? ", ButtonType.OK, ButtonType.NO);
            alert.showAndWait();
            if (alert.getButtonTypes().equals(ButtonType.OK)) {
                if (PlantModel.remove(txtId.getText())) {
                    new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void updateOnAction(ActionEvent actionEvent) {
        PlantUpdateFromController.textId=txtId.getText();
        Navigation.popupNavigation("PlantUpdateFrom.fxml");
    }

    public void setData(Plant plant) {
        txtId.setText(plant.getPlant_id());
        txtPlant.setText(plant.getPlant());
        txtSm.setText(String.valueOf(plant.getAvg_soil_moisture()));
        txtTem.setText(String.valueOf(plant.getAvg_temp()));
        txtWPD.setText(String.valueOf(plant.getWater_per_day()));
        txtHTime.setText(String.valueOf(plant.getHarvest_time()));
        txtLifeTime.setText(String.valueOf(plant.getLife_time()));
    }
}
