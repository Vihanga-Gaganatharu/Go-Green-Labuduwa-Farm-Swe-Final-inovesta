package controller;

import com.jfoenix.controls.JFXCheckBox;
import db.Db;
import dto.GreenHouseSection;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class WaterApplySectionBarController implements Initializable   {
    public JFXCheckBox btnSelect;
    public Text txtId;

    public void select(ActionEvent actionEvent) {
        if (btnSelect.isSelected()){
            System.out.println(Db.waterApplyManually.indexOf(txtId.getText()));
            if (Db.waterApplyManually.indexOf(txtId.getText())<0){
                Db.waterApplyManually.add(txtId.getText());
            }
        }else {
                Db.waterApplyManually.remove(txtId.getText());
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    public void setData(GreenHouseSection g) {
        txtId.setText(g.getGreen_house_section_id());
    }
}
