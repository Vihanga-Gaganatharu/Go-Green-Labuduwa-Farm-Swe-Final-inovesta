package controller;

import dto.custom.Weather;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.util.Duration;
import util.Navigation;
import util.TimelineApiForecastSample;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class DashboardNavController implements Initializable {
    private static DashboardNavController controller;
    public Text txtWeather1;
    public ImageView imgWeather1;
    public Text txtDay1;
    public Text txtWeather2;
    public Text txtDay2;
    public ImageView imgWeather2;
    public Text txtWeather3;
    public ImageView imgWeather3;
    public Text txtDay3;
    public ImageView imgWeather4;
    public Text txtDay4;
    public Text txtWeather5;
    public ImageView imgWeather5;
    public Text txtDay5;
    public Text txtWeather6;
    public ImageView imgWeather6;
    public Text txtDay6;
    public Text txtWeather7;
    public ImageView imgWeather7;
    public Text txtDay7;
    public Text txtWeather4;
    public Text txtH;
    public Text txtTem;
    public Text txtM;

    public DashboardNavController() {
        controller=this;
    }

    public static DashboardNavController getController() {
        return controller;
    }

    public void plantOnAction(ActionEvent actionEvent) {
        translateTransition();
        DashboardController.getController().mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(DashboardController.getController().mainPane, "PlantManage.fxml");
    }

    public void fertilizerOnAction(ActionEvent actionEvent) {
        translateTransition();
        DashboardController.getController().mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(DashboardController.getController().mainPane, "SuppliersManage.fxml");
    }

    public void waterOnAction(ActionEvent actionEvent) {
        translateTransition();
        DashboardController.getController().mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(DashboardController.getController().mainPane, "WaterManage.fxml");
    }

    public void reportOnAction(ActionEvent actionEvent) {
        translateTransition();
        DashboardController.getController().mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(DashboardController.getController().mainPane, "Report.fxml");
    }

    public void employeeOnAction(ActionEvent actionEvent) {
        translateTransition();
        DashboardController.getController().mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(DashboardController.getController().mainPane, "EmployeeDashbord.fxml");
    }

    private void translateTransition() {
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(DashboardController.getController().navePane);
        translate.setDuration(Duration.millis(500));
        translate.setByX(200);
        translate.play();

        TranslateTransition translate2 = new TranslateTransition();
        translate2.setNode(DashboardController.getController().navePane2);
        translate2.setDuration(Duration.millis(500));
        translate2.setByX(-200);
        translate2.play();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ArrayList<Text> weatherTexts = new ArrayList<>();
        weatherTexts.add(txtWeather1);
        weatherTexts.add(txtWeather2);
        weatherTexts.add(txtWeather3);
        weatherTexts.add(txtWeather4);
        weatherTexts.add(txtWeather5);
        weatherTexts.add(txtWeather6);
        weatherTexts.add(txtWeather7);

        ArrayList<Text> weekTexts = new ArrayList<>();
        weekTexts.add(txtDay1);
        weekTexts.add(txtDay2);
        weekTexts.add(txtDay3);
        weekTexts.add(txtDay4);
        weekTexts.add(txtDay5);
        weekTexts.add(txtDay6);
        weekTexts.add(txtDay7);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {

                    ArrayList<Weather> weatherList = TimelineApiForecastSample.getWeatherList();
                    for (int i = 0; i < weatherList.size(); i++) {
                        //System.out.println(String.valueOf(weatherList.get(i).getMinTemp())+"F");
                        String datetime = weatherList.get(i).getDatetime();
                        String[] splitDay = datetime.split("-");
                        String[] split = splitDay[2].split("T");
                        String weekDay = findWeekDay(Integer.parseInt(splitDay[0]), Integer.parseInt(splitDay[1]), Integer.parseInt(split[0]));
                        weatherTexts.get(i).setText(weatherList.get(i).getMinTemp() + "F");
                        weekTexts.get(i).setText(weekDay.charAt(0) + "" + weekDay.charAt(1) + weekDay.charAt(2));

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            private String findWeekDay(int year, int month, int dayOfMonth) {
                LocalDate localDate = LocalDate.of(year, month, dayOfMonth);
                java.time.DayOfWeek dayOfWeek = localDate.getDayOfWeek();
                return dayOfWeek.toString();
            }
        };
        runnable.run();


    }
}
