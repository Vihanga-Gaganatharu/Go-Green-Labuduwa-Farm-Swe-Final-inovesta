package controller;

import com.jfoenix.controls.JFXTextField;
import dto.Attendance;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import model.EmployeeAttendanceModel;
import util.DateTimeUtil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class EmployeeAttendanceFromController implements Initializable {
    private static EmployeeAttendanceFromController controller;
    public JFXTextField txtID;
    public VBox vBox;

    public EmployeeAttendanceFromController() {
        controller = this;
    }

    public static EmployeeAttendanceFromController getController() {
        return controller;
    }

    public void idOnAction(ActionEvent actionEvent) {
        try {
            if (EmployeeAttendanceModel.add(new Attendance(
                    DateTimeUtil.dateNow(),
                    DateTimeUtil.timeNow(),
                    "24:00:00",
                    txtID.getText(),
                    null,
                    null

            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
    }

    public void loadData() {
        vBox.getChildren().clear();
        try {
            ArrayList<Attendance> list = EmployeeAttendanceModel.getAll();
            for (int i = 0; i < list.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(EmployeeAttendanceBarController.class.getResource("/view/bar/EmployeeAttendanceBar.fxml"));
                    Parent root = loader.load();
                    EmployeeAttendanceBarController controller = loader.getController();
                    controller.setData(list.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void setSearchData(String text) {
        vBox.getChildren().clear();
        try {
            ArrayList<Attendance> list = EmployeeAttendanceModel.getAllFilter(text);
            for (int i = 0; i < list.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(EmployeeAttendanceBarController.class.getResource("/view/bar/EmployeeAttendanceBar.fxml"));
                    Parent root = loader.load();
                    EmployeeAttendanceBarController controller = loader.getController();
                    controller.setData(list.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }
}
