package controller;

import com.jfoenix.controls.JFXTextField;
import dto.Employee;
import dto.Plant;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import model.EmployeeModel;
import model.PlantModel;
import util.Navigation;

import java.sql.SQLException;

public class EmployeeAddFromController {

    public JFXTextField txtFirstName;
    public JFXTextField txtLastName;
    public JFXTextField txtMail;
    public JFXTextField txtStreet;
    public JFXTextField txtLane;
    public JFXTextField txtCity;
    public JFXTextField txtContact;
    public JFXTextField txtNic;
    public JFXTextField txtNo;

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (EmployeeModel.add(new Employee(
                    txtNic.getText(),
                    txtFirstName.getText(),
                    txtLastName.getText(),
                    txtCity.getText(),
                    txtLane.getText(),
                    txtStreet.getText(),
                    txtNo.getText(),
                    txtMail.getText(),
                    txtContact.getText()
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private String getNewId() {
        return "@E001";
    }
}
