package controller;

import javafx.event.ActionEvent;
import javafx.scene.text.Text;

public class GroupBarController {
    public Text txtId;
    public Text txtPlant;
    public Text txtPlantCount;
    public Text txtLCount;
    public Text txtDate;
    public Text txtStatus;
    public Text txtDCount;

    public void updateOnAction(ActionEvent actionEvent) {
    }

    public void viewOnAction(ActionEvent actionEvent) {
    }

    public void deleteOnAction(ActionEvent actionEvent) {

    }
}
