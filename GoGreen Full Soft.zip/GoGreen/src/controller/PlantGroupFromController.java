package controller;

import dto.Employee;
import dto.custom.PlantGroupCust;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;
import model.EmployeeModel;
import model.PlantGroupModel;
import util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PlantGroupFromController implements Initializable {
    private static PlantGroupFromController controller;

    public PlantGroupFromController() {
        controller=this;
    }

    public static PlantGroupFromController getController() {
        return controller;
    }

    public VBox vBox;

    public void addOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("PlantGroupAddFrom.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();

    }

    public  void searchData(String txt) {
        PlantGroupFromController.getController().vBox.getChildren().clear();
        try {
            ArrayList<PlantGroupCust> p= PlantGroupModel.getSearchData(txt);
            for (int i = 0; i < p.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(PlantGroupBarController.class.getResource("/view/bar/PlantGroupBar.fxml"));
                    Parent root = loader.load();
                    PlantGroupBarController controller = loader.getController();
                    controller.setData(p.get(i));
                    PlantGroupFromController.getController().vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    public void loadData() {
        vBox.getChildren().clear();
        try {
            ArrayList<PlantGroupCust> p= PlantGroupModel.get();
            for (int i = 0; i < p.size(); i++) {
                try {
                    FXMLLoader loader = new FXMLLoader(PlantGroupBarController.class.getResource("/view/bar/PlantGroupBar.fxml"));
                    Parent root = loader.load();
                    PlantGroupBarController controller = loader.getController();
                    controller.setData(p.get(i));
                    vBox.getChildren().add(root);
                } catch (IOException e) {
                }
            }

        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

}
