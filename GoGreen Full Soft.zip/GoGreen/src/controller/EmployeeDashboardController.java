package controller;

import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import util.Navigation;
import view.tm.EmployeeTm;


import java.net.URL;
import java.util.ResourceBundle;

public class EmployeeDashboardController implements Initializable {


    public JFXRadioButton RBtnEmployee;
    public JFXRadioButton rBtnAttendance;
    public Pane pane;
    public JFXTextField txtText;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        rBtnAction();
    }

    public void newOnAction(ActionEvent actionEvent) {
       Navigation.popupNavigation("EmployeeAddFrom.fxml");
    }

    public void employeeRBtnOnAction(ActionEvent actionEvent) {
      rBtnAction();
    }

    private void rBtnAction() {
        if (RBtnEmployee.isSelected()){
            pane.getChildren().clear();
            Navigation.onTheTopNavigation(pane,"Emplyoyee.fxml");
        }else if (rBtnAttendance.isSelected()){
            pane.getChildren().clear();
            Navigation.onTheTopNavigation(pane,"EmployeeAttendance.fxml");
        }
    }

    public void employeeAttendanceRBtnOnAction(ActionEvent actionEvent) {
rBtnAction();
    }

    public void onKeyReleased(KeyEvent keyEvent) {
        if (RBtnEmployee.isSelected()){
            if (txtText.getText().isEmpty()){
                EmployeeController.getController().getIds();
            }else {
                EmployeeController.getController().getIds();
            }

        }else if (rBtnAttendance.isSelected()){
            if (txtText.getText().isEmpty()){
                EmployeeAttendanceFromController.getController().setSearchData(txtText.getText());
            }else {
                EmployeeAttendanceFromController.getController().loadData();
            }
        }
    }
}
