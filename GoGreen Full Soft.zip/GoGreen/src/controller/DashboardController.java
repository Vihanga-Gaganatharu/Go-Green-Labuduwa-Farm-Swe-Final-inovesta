package controller;

import com.fazecast.jSerialComm.SerialPort;
import db.Db;
import dto.custom.AD;
import dto.custom.Weather;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import util.Navigation;
import util.TimelineApiForecastSample;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import static java.util.GregorianCalendar.AD;

public class DashboardController implements Initializable {
    private static DashboardController controller;
    public Pane navePane;
    public Pane navePane2;
    public Pane mainPane;

    public DashboardController() {
        controller = this;
    }

    public static DashboardController getController() {
        return controller;
    }

    public void click(ActionEvent event) {

        TranslateTransition translate = new TranslateTransition();
        translate.setNode(navePane);
        translate.setDuration(Duration.millis(500));
        translate.setByX(200);
        translate.play();

        TranslateTransition translate2 = new TranslateTransition();
        translate2.setNode(navePane2);
        translate2.setDuration(Duration.millis(500));
        translate2.setByX(-200);
        translate2.play();

        System.out.println("click");
      /*  TranslateTransition translate = new TranslateTransition();
        translate.setNode(navePane);
        translate.setDuration(Duration.millis(500));
        translate.setByX(-200);
        translate.play();

        TranslateTransition translate2 = new TranslateTransition();
        translate2.setNode(navePane2);
        translate2.setDuration(Duration.millis(500));
        translate2.setByX(200);
        translate2.play();*/
        //Navigation.onTheTopNavigation(mainPane,"DashboardNav.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(navePane);
        translate.setByX(-200);
        translate.play();
        Navigation.onTheTopNavigation(mainPane, "DashboardNav.fxml");

        Thread a = new Thread() {
            public void run() {
                while (true) {
                    SerialPort[] ports = SerialPort.getCommPorts();
                    if (ports.length == 0) {
                        System.out.println("No serial ports found.");
                        return;
                    }
                    SerialPort port = SerialPort.getCommPort("COM3"); // Choose the appropriate port

                    if (port.openPort()) {
                        System.out.println("Port opened successfully.");
                        port.setBaudRate(9600); // Set the same baud rate as in your Arduino code

                        StringBuilder receivedData = new StringBuilder();

                        while (true) {
                            byte[] readBuffer = new byte[128];
                            int numRead = port.readBytes(readBuffer, readBuffer.length);

                            if (numRead > 0) {
                                String data = new String(readBuffer, 0, numRead);

                                // Append received data to the StringBuilder
                                receivedData.append(data);

                                // Check if we have received a complete line of data
                                if (receivedData.toString().contains("\n")) {
                                    String[] values = receivedData.toString().trim().split(",");

                                    if (values.length == 3) {
                                        try {
                                            double temperature = Double.parseDouble(values[0]);
                                            double humidity = Double.parseDouble(values[1]);
                                            int moisture = Integer.parseInt(values[2]);

                                            AD ad=new AD(
                                                    String.valueOf(temperature),
                                                    String.valueOf(humidity),
                                                    String.valueOf(moisture)
                                            );

                                            Db.db.put("G001",ad);
                                            System.out.println(" >>>>>>>>> db ok");

//                                             Now you have the temperature, humidity, and moisture values in your Java program
                                            System.out.println("Temperature: " + temperature + "°C");
                                              System.out.println("Humidity: " + humidity + "%");
                                            System.out.println("Moisture: " + moisture + "%");

                                            /*DashboardNavController.getController().txtH.setText(temperature + "°C");
                                            DashboardNavController.getController().txtTem.setText(humidity + "%");
                                            DashboardNavController.getController().txtM.setText(humidity + "%");*/
                                        } catch (NumberFormatException e) {
                                            System.err.println("Error parsing values: " + e.getMessage());
                                        }
                                    }

                                    // Clear the receivedData StringBuilder for the next set of data
                                    receivedData.setLength(0);
                                }
                            }
                        }
                    } else {
                        System.err.println("Failed to open the port.");
                    }

                }
            }
        };
        //a.start();

        Thread t = new Thread() {
            public void run() {
                while (true){
                    try {
                        DashboardNavController.getController().txtH.setText(Db.db.get("G001").getHumidity());
                        DashboardNavController.getController().txtTem.setText(Db.db.get("G001").getTemperature());
                        DashboardNavController.getController().txtM.setText(Db.db.get("G001").getMoisture());
                    }catch (NullPointerException e){
                        System.out.println("e");
                    }

                    try {
                        sleep(1000);
                    } catch (InterruptedException ex) {
                    }
                }

            }
        };
       // t.start();

    }

    public void homeOnAction(ActionEvent actionEvent) {
        TranslateTransition translate = new TranslateTransition();
        translate.setNode(navePane);
        translate.setDuration(Duration.millis(500));
        translate.setByX(-200);
        translate.play();

        TranslateTransition translate2 = new TranslateTransition();
        translate2.setNode(navePane2);
        translate2.setDuration(Duration.millis(500));
        translate2.setByX(200);
        translate2.play();
        mainPane.getChildren().clear();
        Navigation.onTheTopNavigation(mainPane, "DashboardNav.fxml");
    }

    public void aboutOnAction(ActionEvent actionEvent) {
        Navigation.popupNavigation("AboutFrom.fxml");
    }
}
