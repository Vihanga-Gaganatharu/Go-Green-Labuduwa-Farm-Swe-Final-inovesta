package controller;

import com.jfoenix.controls.JFXTextField;
import dto.GreenHouseSection;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class GroupSectionBarController implements Initializable {
    public Text txtSectionId;
    public Text txtLimit;
    public JFXTextField txtPlantCount;
    private GreenHouseSection section =new GreenHouseSection();
    public void setData(GreenHouseSection data) {
        System.out.println(data.getSection_id());
        txtSectionId.setText(data.getSection_id());
        txtLimit.setText("Limit Of Section : "+data.getPlantLimit());
        section=data;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        PlantGroupAddFromController.sectionData.put(txtSectionId.getText(),0);
    }

    public void typed(KeyEvent keyEvent) {
        if (Integer.parseInt(txtLimit.getText())<section.getPlantLimit()){
            PlantGroupAddFromController.sectionData.put(txtSectionId.getText(),Integer.parseInt(txtPlantCount.getText()));
        }else {
            txtPlantCount.setText("00");
        }
    }
}
