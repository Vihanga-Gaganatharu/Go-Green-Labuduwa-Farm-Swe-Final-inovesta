package controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dto.GreenHouse;
import dto.Plant;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import model.GreenHouseModel;
import model.PlantModel;
import util.DateFormat;
import util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class GreenHouseAddFromController implements Initializable {
    public JFXTextField txtLocation;
    public JFXComboBox cmbWAType;
    public JFXDatePicker dpDate;
    public JFXTextField txtSection;
    public VBox vBoxx;

    public void addOnAction(ActionEvent actionEvent) {
        try {
            if (GreenHouseModel.add(new GreenHouse(
                    getNewId(),
                    DateFormat.dateFormatter(String.valueOf(dpDate.getValue())),
                    txtLocation.getText(),
                    String.valueOf(cmbWAType.getValue())
            ))) {
                new Alert(Alert.AlertType.CONFIRMATION, "ok").show();
            } else {
                new Alert(Alert.AlertType.ERROR, "error").show();
            }
        } catch (SQLException | ClassNotFoundException throwables) {
            throwables.printStackTrace();
        }
    }

    private String getNewId() {
        return "@G002";
    }

    public void closeOnAction(ActionEvent actionEvent) {
        Navigation.close(actionEvent);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ArrayList<String>WPT=new ArrayList<>();
        WPT.add("MANUAL");
        WPT.add("AUTO");
        cmbWAType.getItems().addAll(WPT);
    }

    public void sectionOnAction(ActionEvent actionEvent) {
        vBoxx.getChildren().clear();
        for (int i = 0; i < Integer.parseInt(txtSection.getText()); i++) {
            try {
                FXMLLoader loader = new FXMLLoader(SectionFromController.class.getResource("/view/bar/SectionFrom.fxml"));
                Parent root = loader.load();
                SectionFromController controller = loader.getController();
                controller.setData(i);
                vBoxx.getChildren().add(root);
            } catch (IOException e) {
            }
        }
    }
}
